# PssHandleInformation Fields
 

The <a href="T_DevCase_Interop_Unmanaged_Win32_Structures_PssHandleInformation">PssHandleInformation</a> type exposes the following members.


## Fields
&nbsp;<table><tr><th></th><th>Name</th><th>Description</th></tr><tr><td>![Public field](media/pubfield.gif "Public field")</td><td><a href="F_DevCase_Interop_Unmanaged_Win32_Structures_PssHandleInformation_HandlesCaptured">HandlesCaptured</a></td><td>
The count of handles captured.</td></tr></table>&nbsp;
<a href="#psshandleinformation-fields">Back to Top</a>

## See Also


#### Reference
<a href="T_DevCase_Interop_Unmanaged_Win32_Structures_PssHandleInformation">PssHandleInformation Structure</a><br /><a href="N_DevCase_Interop_Unmanaged_Win32_Structures">DevCase.Interop.Unmanaged.Win32.Structures Namespace</a><br />