# MouseTracker Events
 

The <a href="T_DevCase_ThirdParty_SharpDX_MouseTracker">MouseTracker</a> type exposes the following members.


## Events
&nbsp;<table><tr><th></th><th>Name</th><th>Description</th></tr><tr><td>![Public event](media/pubevent.gif "Public event")</td><td><a href="E_DevCase_ThirdParty_SharpDX_MouseTracker_MouseInput">MouseInput</a></td><td>
Event raised when device muting changes.</td></tr></table>&nbsp;
<a href="#mousetracker-events">Back to Top</a>

## See Also


#### Reference
<a href="T_DevCase_ThirdParty_SharpDX_MouseTracker">MouseTracker Class</a><br /><a href="N_DevCase_ThirdParty_SharpDX">DevCase.ThirdParty.SharpDX Namespace</a><br />