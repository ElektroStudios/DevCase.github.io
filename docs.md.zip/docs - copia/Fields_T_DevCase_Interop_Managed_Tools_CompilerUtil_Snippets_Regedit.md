# Regedit Fields
 

The <a href="T_DevCase_Interop_Managed_Tools_CompilerUtil_Snippets_Regedit">CompilerUtil.Snippets.Regedit</a> type exposes the following members.


## Fields
&nbsp;<table><tr><th></th><th>Name</th><th>Description</th></tr><tr><td>![Public field](media/pubfield.gif "Public field")![Static member](media/static.gif "Static member")</td><td><a href="F_DevCase_Interop_Managed_Tools_CompilerUtil_Snippets_Regedit_HelloWorldv5">HelloWorldv5</a></td><td>
A sourcecode template of a `Hello World` script written in `Windows Registry Editor v5`.</td></tr></table>&nbsp;
<a href="#regedit-fields">Back to Top</a>

## See Also


#### Reference
<a href="T_DevCase_Interop_Managed_Tools_CompilerUtil_Snippets_Regedit">CompilerUtil.Snippets.Regedit Class</a><br /><a href="N_DevCase_Interop_Managed_Tools">DevCase.Interop.Managed.Tools Namespace</a><br />