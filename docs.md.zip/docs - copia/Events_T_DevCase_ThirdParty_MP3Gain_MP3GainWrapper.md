# MP3GainWrapper Events
 

The <a href="T_DevCase_ThirdParty_MP3Gain_MP3GainWrapper">MP3GainWrapper</a> type exposes the following members.


## Events
&nbsp;<table><tr><th></th><th>Name</th><th>Description</th></tr><tr><td>![Public event](media/pubevent.gif "Public event")</td><td><a href="E_DevCase_ThirdParty_MP3Gain_MP3GainWrapper_Exited">Exited</a></td><td>
Event raised when the `MP3Gain.exe` process has exited.</td></tr><tr><td>![Public event](media/pubevent.gif "Public event")</td><td><a href="E_DevCase_ThirdParty_MP3Gain_MP3GainWrapper_ProgressChanged">ProgressChanged</a></td><td>
Event raised when `MP3Gain.exe` progress changes.</td></tr><tr><td>![Public event](media/pubevent.gif "Public event")</td><td><a href="E_DevCase_ThirdParty_MP3Gain_MP3GainWrapper_Started">Started</a></td><td>
Event raised when the `MP3Gain.exe` process has been started.</td></tr></table>&nbsp;
<a href="#mp3gainwrapper-events">Back to Top</a>

## See Also


#### Reference
<a href="T_DevCase_ThirdParty_MP3Gain_MP3GainWrapper">MP3GainWrapper Class</a><br /><a href="N_DevCase_ThirdParty_MP3Gain">DevCase.ThirdParty.MP3Gain Namespace</a><br />